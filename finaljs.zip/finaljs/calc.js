document.getElementById('convertBtn').addEventListener('click', function () {
    const amount = parseFloat(document.getElementById('amount').value);
    const fromCurrency = document.getElementById('fromCurrency').value;
    const toCurrency = document.getElementById('toCurrency').value;

    if (isNaN(amount)) {
        alert("Por favor, insira um valor válido.");
        return;
    }

    // Professor, Taxas de câmbio fictícias não eoncontrei uma API real. 
    const exchangeRates = {
        USD: { BRL: 5.0, EUR: 0.85, GBP: 0.73 },
        BRL: { USD: 0.2, EUR: 0.17, GBP: 0.15 },
        EUR: { USD: 1.18, BRL: 5.88, GBP: 0.86 },
        GBP: { USD: 1.37, BRL: 6.82, EUR: 1.16 }
    };

    const rate = exchangeRates[fromCurrency][toCurrency];
    const convertedAmount = (amount * rate).toFixed(2);

    document.getElementById('resultText').innerText = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
});