document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("destino-input");
    const button = document.getElementById("add-botao");
    const ul = document.getElementById("destino-ul");

    // Recuperar localstorage
    const savedDestinos = JSON.parse(localStorage.getItem("destinos")) || [];
    savedDestinos.forEach(dest => addDestinoToList(dest));

    button.addEventListener("click", () => {
        const destino = input.value.trim();
        if (destino) {
            addDestinoToList(destino);
            saveDestino(destino);
            input.value = "";
        }
    });

    function addDestinoToList(destino) {
        const li = document.createElement("li");
        li.textContent = destino;
        ul.appendChild(li);
    }

    function saveDestino(destino) {
        const destinos = JSON.parse(localStorage.getItem("destinos")) || [];
        destinos.push(destino);
        localStorage.setItem("destinos", JSON.stringify(destinos));
    }
});

// Seleciona experiência nômade

document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("destino-input");
    const button = document.getElementById("add-botao");
    const ul = document.getElementById("destino-ul");
    const yesButton = document.getElementById("sim-botao");
    const noButton = document.getElementById("nao-botao");
    const responseText = document.getElementById("resposta-experiencia");

    // Recuperar localstorage
    const savedDestinos = JSON.parse(localStorage.getItem("destinos")) || [];
    savedDestinos.forEach(dest => addDestinoToList(dest));

    button.addEventListener("click", () => {
        const destino = input.value.trim();
        if (destino) {
            addDestinationToList(destino);
            saveDestination(destino);
            input.value = "";
        }
    });

    yesButton.addEventListener("click", () => {
        responseText.textContent = "Que incrível! Compartilhe suas experiências com a comunidade!";
    });

    noButton.addEventListener("click", () => {
        responseText.textContent = "Sem problemas! Aqui você pode conhecer mais sobre esse estilo de vida!";
    });

    function addDestinoToList(destino) {
        const li = document.createElement("li");
        li.textContent = destino;
        ul.appendChild(li);
    }

    function saveDestino(destino) {
        const destinos = JSON.parse(localStorage.getItem("destinos")) || [];
        destinos.push(destino);
        localStorage.setItem("destinos", JSON.stringify(destinos));
    }
});
