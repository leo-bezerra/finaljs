const header = document.querySelector("header");
const footer = document.querySelector("footer");

// Adiciona o modal ao final do body
document.body.insertAdjacentHTML("beforeend", `
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="modal-body"></div> <!-- Aqui o conteúdo será carregado -->
        </div>
    </div>
`);

header.innerHTML = `
<div class="menu-conteudos">
    <div class="logo">    
        <a href="index.html">
            <img src="assets/images/logonomade.png" alt="Logo do site">
        </a>
    </div>

    <nav class="menu-d">
        <div class="alt-menu">
            <ul>
                <li><a class="links" href="index.html" target="_self">Home</a></li>
                <li><a class="links" href="Dica_viajante.html" target="_self">Dicas</a></li>
                <li><a class="links" href="dia-a-dia.html" target="_self">Dia a dia</a></li>
                <li><a class="links" href="vagasremotas.html" target="_self">Vagas</a></li>
                <li><a class="links" href="servicos.html" target="_self">Serviços</a></li>
            </ul>
        </div>
    </nav>

    <div id="menuToggle">
        <input type="checkbox" />
        <span></span>
        <span></span>
        <span></span>
        <ul class="menu-mobile">
            <li><a class="links-m" href="index.html"><span class="material-icons">other_houses</span>Home</a></li>
            <li><a class="links-m" href="Dica_viajante.html"><span class="material-icons">diversity_1</span>Dicas</a></li>
            <li><a class="links-m" href="dia-a-dia.html"><span class="material-icons">explore</span>Dia a dia</a></li>
            <li><a class="links-m" href="vagasremotas.html"><span class="material-icons">flight_takeoff</span>Vagas</a></li>
            <li><a class="links" href="calculadora.html" target="_self">Serviços</a></li>
        </ul>
    </div>
</div>
`;

footer.innerHTML = `
<div class="rodape-area">
    <div class="rodape-conteudos"><img src="assets/images/logotipo.png" alt="Logotipo nomades"></div>
    <div class="rodape-conteudos">
        <h4 class="titulo-footer termos">Termos e Privacidade</h4>
        <ul class="lista-footer">
            <li><a class="links-footer" href="#" target="_self">Termos de uso</a></li>
            <li><a class="links-footer" href="#" target="_self">Política de Cookies</a></li>
            <li><a class="links-footer" href="#" target="_self">Privacidade</a></li>
        </ul>
    </div>
    <div class="rodape-conteudos">
        <h4 class="titulo-footer canais">Canais para contato</h4>
        <p>(84) 99640-1000</p>
        <p>contato@nomadespelomundo.com.br</p>
        <div class="area-sociais">
            <div class="icone-sociais"><img src="assets/images/sociais/face.png" alt="Logo facebook"></div>
            <div class="icone-sociais"><img src="assets/images/sociais/insta.png" alt="Logo instagram"></div>
            <div class="icone-sociais"><img src="assets/images/sociais/link.png" alt="Logo linkedin"></div>
            <div class="icone-sociais"><img src="assets/images/sociais/whats.png" alt="Logo whatsapp"></div>
        </div>
    </div>
</div>
`;

// Lógica do Modal
document.addEventListener("DOMContentLoaded", function() {
    const modal = document.getElementById("myModal");
    const modalBody = document.getElementById("modal-body");
    const closeModal = document.querySelector(".close");

    // Função para abrir o modal e carregar o conteúdo
    function openModal(url) {
        fetch(url) // Faz uma requisição para carregar o conteúdo da página
            .then(response => response.text()) // Converte a resposta em texto
            .then(data => {
                modalBody.innerHTML = data; // Insere o conteúdo no modal
                modal.style.display = "block"; // Exibe o modal
            })
            .catch(error => {
                console.error("Erro ao carregar o conteúdo:", error);
                modalBody.innerHTML = "<p>Erro ao carregar o conteúdo.</p>"; // Mensagem de erro
                modal.style.display = "block";
            });
    }

    // Função para fechar o modal
    function closeModalFunc() {
        modal.style.display = "none";
        modalBody.innerHTML = ""; // Limpa o conteúdo ao fechar
    }

    // Adicionar evento de clique ao link "Conversor de Moedas" (desktop)
    const conversorLinkDesktop = document.querySelector('.menu-d a[href="calculadora.html"]');
    if (conversorLinkDesktop) {
        conversorLinkDesktop.addEventListener("click", function(event) {
            event.preventDefault(); // Prevenir o comportamento padrão do link
            openModal(this.href);
        });
    }

    // Adicionar evento de clique ao link "Conversor de Moedas" (mobile)
    const conversorLinkMobile = document.querySelector('.menu-mobile a[href="calculadora.html"]');
    if (conversorLinkMobile) {
        conversorLinkMobile.addEventListener("click", function(event) {
            event.preventDefault(); // Prevenir o comportamento padrão do link
            openModal(this.href);
        });
    }

    // Fechar o modal ao clicar no botão de fechar
    closeModal.addEventListener("click", closeModalFunc);

    // Fechar o modal ao clicar fora do conteúdo do modal
    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            closeModalFunc();
        }
    });
});